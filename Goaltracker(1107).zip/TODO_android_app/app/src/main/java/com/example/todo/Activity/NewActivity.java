package com.example.todo.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.example.todo.Adapter.MiniCardAdapter;
import com.example.todo.Database.NotesDatabase;
import com.example.todo.MainActivity;
import com.example.todo.Model.NotesModel;
import com.example.todo.R;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class NewActivity extends AppCompatActivity {

    public boolean goalflag = false;
    RecyclerView recyclerView;
    MiniCardAdapter minicardAdapter;
    RelativeLayout relativeLayout;
    ArrayList<NotesModel> notesModelArrayList;
    NotesDatabase notesDatabase;
    Intent intent;
    TextView progressperc, goalsremaining;
    public int x, y ;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);
        recyclerView = findViewById(R.id.goalsrv);
        LinearLayout goalLayout = findViewById(R.id.goalslyt);
        LinearLayout progresslyt = findViewById(R.id.ProgressLyt);
        ScrollView scrollView = findViewById(R.id.scrollview1);
        Button seteditgoal = findViewById(R.id.seteditgoal);
        progressperc = findViewById(R.id.progressperc);
        goalsremaining = findViewById(R.id.goalsremaining);

        notesDatabase=new NotesDatabase(this,"notes_db",null,1);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);

        recyclerView.setLayoutManager(linearLayoutManager);

        notesModelArrayList=new ArrayList<>(notesDatabase.getAllData());
        minicardAdapter = new MiniCardAdapter(this,notesModelArrayList,this::onClickCard);
        recyclerView.setAdapter(minicardAdapter);
        minicardAdapter.notifyDataSetChanged();

        x = minicardAdapter.getItemCount();
        String countString = String.valueOf(x);
        goalsremaining.setText(countString);


        if(minicardAdapter.getItemCount()==0){
            relativeLayout.setVisibility(View.VISIBLE);
        }

        goalLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start GoalsActivity
                Intent intent = new Intent(NewActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        progresslyt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start GoalsActivity
                Intent intent = new Intent(NewActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        if (!goalflag) {
            seteditgoal.setText("Set Goals");
        } else {
            seteditgoal.setText("Edit Goal");
        }

        seteditgoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start GoalsActivity
                Intent intent = new Intent(NewActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        scrollView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }
    public void onClickCard(int position) {
        int id=notesModelArrayList.get(position).getNotesId();
        intent=new Intent(NewActivity.this, UpdateNoteActivity.class);
        intent.putExtra("noteId",id);
        startActivity(intent);
    }
}